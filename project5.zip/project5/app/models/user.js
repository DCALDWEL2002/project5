/**
 * Created by dcaldwel2002 on 4/26/17.
 */
//grab the packages that we need for the user model
// grab packages needed for the user model
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//var bcrypt = require('bcrypt-nodejs');

// user schema  **these should be required but I am testing and trying to figure out where I went wrong
// i used the book example from "Building a Restful Node" app/model/user.js
var UserSchema = new Schema({
    review: String,
    movie: {type: String},
    year: {type: String},
    actor: {type: [String]}

});
// save the movie
UserSchema.pre('save', function(next) {
    var movie = this;
})

// return the model
module.exports = mongoose.model('Movie', UserSchema);
