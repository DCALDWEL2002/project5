//denise caldwell
//server.js
//edited for project 5 from project4
// BASE setup

// call packages
var express     = require('express');
var app         = express();
var bodyParser  = require('body-parser');
var morgan      = require('morgan');
var mongoose    = require('mongoose');
var port        = process.env.PORT || 8080;

// pulls in the user model
var Movie        = require('./app/models/user');

// App config
// uses body-parser so we can grab info from POST requests
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

// configure the app to handle cors requests - GET/POST
app.use(function(req, res, next){
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Authorization');
    next();
});

// log all requests to the console
app.use(morgan('dev'));


mongoose.Promise = global.Promise;
// connect to the database (hosted on mlabs.com)
mongoose.connect('mongodb://Cake:Cake1@ds157390.mlab.com:57390/dcmovies');

// Routes for API

// home page route
app.get('/', function(req, res){
    res.send('Welcome to the home page!');
})

// get an instance of the express router
var apiRouter = express.Router();

// middleware to use for all the requests
apiRouter.use(function (req, res, next) {
    // do logging
    console.log('Somebody just came to our app!');

    // more added in ch 10
    // this is where users are authenticated

    next(); // makes sure we go to the next routes and dont stop here
});

// test route to make sure everything is working
// accessed at GET http://localhost:8080/api
apiRouter.get('/', function(req, res){
    res.json({message: 'hooray! welcome to our api!'});
});


// on routes that end in /movies
apiRouter.route('/movies')


// create a user (accessed at POST http://localhost:8080/api/users
    .post(function(req, res){

        // create a new instance of the user model
        var movie = new Movie();

        // set the user's information (comes from the request)
        movie.Title = req.body.title;
        movie.Year  = req.body.year;
        movie.Actor = req.body.actor;
        movie.Review = req.body.review;

        // save the user and check for errors
        movie.save(function(err){
            if(err){
                // duplicate entry
                if(err.code == 11000)
                    return res.json({success:false, message:
                        'A movie Title with that name already exists.'});
                else
                    return res.send(err);
            }

            res.json({message: 'Movie created!'});

        });
    })
    // end .post function
    // get all the users (accessed at GET http://localhost:8080/api/movies)
    .get(function(req, res){
        Movie.find(function(err, movie){
            if(err) res.send(err);

            //returns all the movies
            res.json(movie);
        });
    }); // semi-colon at the end of all the http word functions

// on routes that end in /users/:user_id

apiRouter.route('/movies/movie_title')

// get the movie with that movie title
// accessed at GET http://localhost:8080/api/movies
    .get(function (req, res) {
        Movie.find(req.params.movie_title, function(err, movie){

            if (err) res.send(err);

            //return that movie
            res.json(movie);
        });
    })

    // update the movie with this title
    // accessed at PUT http://localhost:8080/api/movies/:movie_title
    .put(function (req, res) {

        // use the user model to find the user we want
        Movie.find(req.params.movie_title, function(err, movie){

            if(err) res.send(err);

            // update the movie's info only if it's new
            if (req.body.title) movie.title = req.body.title;
            if (req.body.year) movie.year = req.body.year;
            if (req.body.actor) movie.actor = req.body.actor;
            if (req.body.review) movie.review = req.body.review;

            // save the movie
            Movie.save(function(err){
                if(err) res.send(err);

                // return a message
                res.json({message: 'movie updated!'});
            });
        });
    })
//delete a movie by movie title name
// accessed at DELETE http://localhost:8080/api/movies/:movie_title
    .delete(function (req, res) {
        Movie.remove({
            _title: req.params.movie_title
        }, function(err, movie){
            if (err) return res.send(err);

            res.json({message: 'Successfully deleted'});
        });
    });

apiRouter.route('/movies/movie_review')

// get the review for a specific movie
// accessed at GET http://localhost:8080/api/movies/:movie_review
        .get(function (req, res) {
            Movie.find(req.params.movie_title, function(err, movie){
                if (err) res.send(err);
            Movie.find(req.params.movie_review, function(err, movie){
                        if (err) res.send(err);
                        //return that movie
                        res.json(movie);
                        //return that movie_review
                        res.json(movie_review);
                    });
                })
        })

// register our routes
// all routes prefixed with /api
app.use('/api', apiRouter);

// start the server
app.listen(port);
console.log('Magic happens on port ' + port);
